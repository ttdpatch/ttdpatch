<? /* TTDPatch Manual: CHM version preparation script. Copyright (c) Owen Rudge 2002 */

echo("HTML to CHM preparation script for TTDPatch manual\nVersion 1.0\nCopyright (c) Owen Rudge 2002. All Rights Reserved.\n\n");

echo("Writing HTML Help project file...\n");

$hhp = fopen("ttdpatch.hhp", "wt");

fwrite($hhp, '[OPTIONS]
Compatibility=1.1 or later
Compiled file=ttdpatch.chm
Contents file=ttdpatch.hhc
Default topic=index.htm
Display compile progress=No
Full-text search=Yes
Index file=ttdpatch.hhk
Language=0x809 English (United Kingdom)
Title=TTDPatch Manual


[FILES]
');

echo("Preparing HTML files...\n");

if ($handle = opendir('.'))
{
   while (false !== ($file = readdir($handle)))
   { 
      if ($file != "." && $file != ".." && strstr($file, ".htm") != FALSE)
      { 
         fwrite($hhp, "$file\n");

         $fh = fopen($file, "rt");
         $fw = fopen($file . ".new", "wt");

         while (!feof($fh))
         {
            if (eregi("<link href=\"http://texinfo.org/\" rel=generator-home>", $line = fgets($fh, 1024)))
            {
               fwrite($fw, $line);
               break;
            }

            fwrite($fw, $line);
         }

         fwrite($fw, "<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">\n");

         while (!feof($fh))
         {
            $line = fgets($fh, 1024);
            fwrite($fw, $line);
         }

         fclose($fw);
         fclose($fh);

         unlink($file);
         copy($file . ".new", $file);
         unlink($file . ".new");
      } 
   }

   closedir($handle); 
}

fclose($hhp);

echo("Creating HTML Help contents file...\n");

// Now create the ttdpatch.hhc file

$fw = fopen("ttdpatch.hhc", "wt");

fwrite($fw, '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<OBJECT type="text/site properties">
	<param name="Window Styles" value="0x800025">
</OBJECT>
<UL>');

$fh = fopen("index.htm", "rt");

while (!feof($fh))
{
   if (eregi("<h2>Table of Contents</h2>", $line = fgets($fh, 1024)))
      break;
}

while (!feof($fh))
{
   $line = fgets($fh, 1024);

   if (eregi("<ul>", $line))
   {
      while (!feof($fh))
      {
         $line = fgets($fh, 1024);

         if (eregi("<li><a name=", $line))
         {
            $line = fgets($fh, 1024);
            $line = str_replace("<a href=\"", "<LI> <OBJECT type='text/sitemap'><param name='Local' value='", $line);
            $line = str_replace("\">", "'><param name='Name' value='", $line);
            $line = str_replace("</a>", "'></OBJECT>", $line);
         }
         else
         {
         $line = str_replace("<li><a href=\"", "<LI> <OBJECT type='text/sitemap'><param name='Local' value='", $line);
         $line = str_replace("\">", "'><param name='Name' value='", $line);
         $line = str_replace("</a>", "'></OBJECT>", $line);
}
//         if (eregi("<li><a href=\\\"([^\\[]+)\\\">([^\\[]*)\\\"></a>", $line, $regs) == FALSE)
//            echo("FALSE: " . $line);

//         eregi("<a href=\"(^[[:alnum:]]+$)\">(^[[:alnum:]]+$)</a>", $line, $regs);

         $line = str_replace("'", "\"", $line);

         fwrite($fw, $line); /*'<LI> <OBJECT type="text/sitemap">
		<param name="Name" value="' . $title . '">
		<param name="Local" value="' . $fn . '">
		</OBJECT>
	<UL>');*/
      }     
   }
}

fclose($fh);
fclose($fw);

// now create the ttdpatch.hhk file

echo("Writing HTML Help index file...\n");

$fw = fopen("ttdpatch.hhk", "wt");

fwrite($fw, '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<UL>
');

$fh = fopen("index.html", "rt");

while (!feof($fh))
{
   if (eregi("<ul compact>", $line = fgets($fh, 1024)))
      break;
}

while (!feof($fh))
{
   $line = fgets($fh, 1024);

   if (eregi("</ul>", $line))
      break;
    
   $line = str_replace("<tt>", "", $line);
   $line = str_replace("</tt>", "", $line);
   $line = str_replace("<code>", "", $line);
   $line = str_replace("</code>", "", $line);
   $line = str_replace(": ", "", $line);
   $line = str_replace(", ", "", $line);

   $line = str_replace("<li>", "<LI><OBJECT type='text/sitemap'><param name='Name' value='", $line);
   $line = str_replace("<a href=\"", "'><param name='Local' value='", $line);
   $line = str_replace("\">", "'><param name='Name' value='", $line);
   $line = str_replace("</a>", "'>", $line);

   $line = str_replace("'", "\"", $line);
   $line .= "</OBJECT>";

   fwrite($fw, $line);
}

fwrite($fw, "</UL></BODY></HTML>");

fclose($fh);
fclose($fw);
?>
